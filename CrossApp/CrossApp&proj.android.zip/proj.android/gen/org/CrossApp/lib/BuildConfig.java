/** Automatically generated file. DO NOT MODIFY */
package org.CrossApp.lib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}